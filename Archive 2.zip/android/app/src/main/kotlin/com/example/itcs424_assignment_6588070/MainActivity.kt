package com.example.itcs424_assignment_6588070

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
