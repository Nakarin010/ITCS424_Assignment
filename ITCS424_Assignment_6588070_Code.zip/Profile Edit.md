Patient’ Profile
- Edit and save
Appointment History
- see all past and upcoming apoinments